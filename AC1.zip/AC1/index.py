from flask import Flask, request, render_template
from contextlib import closing
import sqlite3

app = Flask(__name__)

@app.route("/")
def menu():
    return render_template("menu.html", mensagem = "")

@app.route("/jogo")
def listar_jogos_api():
    return render_template("lista_jogos.html", jogos = listar_jogos())

@app.route("/jogo/novo", methods = ["GET"])
def form_criar_jogo_api():
    return render_template("form_jogo.html", id_jogo = "novo", nome_jogo = "", descricao = "", valor = "", plataforma = "")

@app.route("/jogo/novo", methods = ["POST"])
def criar_jogo_api():
    nome_jogo = request.form["nome_jogo"]
    descricao = request.form["descricao"]
    valor = request.form["valor"]
    plataforma = request.form["plataforma"]
    id_jogo = criar_jogo(nome_jogo, descricao, valor, plataforma)
    return render_template("menu.html", mensagem = f"O Jogo {nome_jogo} foi Cadastrado!!")

@app.route("/jogo/<int:id_jogo>", methods = ["GET"])
def form_alterar_jogo_api(id_jogo):
    jogo = consultar_jogo(id_jogo)
    if jogo == None:
        return render_template("menu.html", mensagem = f"Jogo não existente!!"), 404
    return render_template("form_jogo_.html", id_jogo = id_jogo, nome_jogo = jogo['nome_jogo'], descricao = jogo['descricao'], valor = jogo['valor'], plataforma = jogo['plataforma'])

@app.route("/jogo/<int:id_jogo>", methods = ["POST"])
def altera_jogo_api(id_jogo):
    nome_jogo = request.form["nome_jogo"]
    descricao = request.form["descricao"]
    valor = request.form["valor"]
    plataforma = request.form["plataforma"]
    jogo = consultar_jogo(id_jogo)
    if jogo == None:
        return render_template("menu.html", mensagem = f"Jogo não existente!!"), 404
    editar_jogo(id_jogo, nome_jogo, descricao, valor, plataforma)
    return render_template("menu.html", mensagem = f"Jogo {nome_jogo} alterado com Sucesso!!")

@app.route("/jogo/deletar/<int:id_jogo>", methods = ["GET"])
def deletar_jogo_api(id_jogo):
    jogo = consultar_jogo(id_jogo)
    if jogo == None:
        return render_template("menu.html", mensagem = f"Jogo não existente!!"), 404
    deletar_jogo(id_jogo)
    return render_template("menu.html", mensagem = f"Jogo deletado com Sucesso!!")

def row_to_dict(description, row):
    if row == None:
        return None
    d = {}
    for i in range(0, len(row)):
        d[description[i][0]] = row[i]
    return d


def rows_to_dict(description, rows):
    result = []
    for row in rows:
        result.append(row_to_dict(description, row))
    return result


@app.route("/cliente/novo", methods = ["GET"])
def form_criar_cliente_api():
    return render_template("form_cliente.html", id_cliente = "novo", nome_cliente = "", login = "", senha = "", cpf = "")

@app.route("/cliente/novo", methods = ["POST"])
def criar_cliente_api():
    nome_cliente = request.form["nome_cliente"]
    login = request.form["login"]
    senha = request.form["senha"]
    cpf = request.form["cpf"]
    id_cliente = criar_cliente(nome_cliente, login, senha, cpf)
    return render_template("menu.html", mensagem = f"O Cliente {nome_cliente} foi Cadastrado!!")

@app.route("/cliente")
def listar_clientes_api():
    return render_template("lista_clientes.html", clientes = listar_clientes())

@app.route("/cliente/<int:id_cliente>", methods = ["GET"])
def form_alterar_cliente_api(id_cliente):
    cliente = consultar_cliente(id_cliente)
    if cliente == None:
        return render_template("menu.html", mensagem = f"Cliente não existente!!"), 404
    return render_template("form_cliente_.html", id_cliente = id_cliente, nome_cliente = cliente['nome_cliente'], login = cliente['login'], senha = cliente['senha'], cpf = cliente['cpf'])

@app.route("/cliente/<int:id_cliente>", methods = ["POST"])
def altera_cliente_api(id_cliente):
    nome_cliente = request.form["nome_cliente"]
    login = request.form["login"]
    senha = request.form["senha"]
    cpf = request.form["cpf"]
    cliente = consultar_cliente(id_cliente)
    if cliente == None:
        return render_template("menu.html", mensagem = f"Cliente não existente!!"), 404
    editar_cliente(id_cliente, nome_cliente, login, senha, cpf)
    return render_template("menu.html", mensagem = f"Cliente {nome_cliente} alterado com Sucesso!!")

@app.route("/cliente/deletar/<int:id_cliente>", methods = ["GET"])
def deletar_cliente_api(id_cliente):
    cliente = consultar_cliente(id_cliente)
    if cliente == None:
        return render_template("menu.html", mensagem = f"Cliente não existente!!"), 404
    deletar_cliente(id_cliente)
    return render_template("menu.html", mensagem = f"Cliente deletado com Sucesso!!")

@app.route("/login", methods = ["GET"])
def form_login():
    return render_template("login.html", login = "", senha = "")

@app.route("/pedido/novo", methods = ["GET"])
def form_insere_jogo():
    return render_template("form_insere_jogo.html", id_pedido = "novo", clientes = listar_clientes(), jogos = listar_jogos())

@app.route("/pedido/novo", methods = ["POST"])
def criar_pedido_api():
    nome_cliente = request.form["nome_cliente"]
    nome_jogo = request.form["nome_jogo"]
    unidades = request.form["unidades"]
    id_pedido = criar_pedido(nome_cliente, nome_jogo, unidades)
    return render_template("menu.html", mensagem = f"Pedido do Cliente {nome_cliente}")

@app.route("/pedido")
def listar_pedido_api():
    return render_template("lista_pedidos.html", pedidos = listar_pedidos())

@app.route("/pedido/<int:id_pedido>", methods = ["GET"])
def form_alterar_pedido_api(id_pedido):
    pedido = consultar_pedido(id_pedido)
    if pedido == None:
        return render_template("menu.html", mesagem = f"Pedido não existente!!"), 404
    return render_template("form_insere_jogo.html", id_pedido = id_pedido, clientes = listar_clientes(), jogos = listar_jogos())

@app.route("/pedido/<int:id_pedido>", methods = ["POST"])
def alterar_pedido_api(id_pedido):
    nome_cliente = request.form["nome_cliente"]
    nome_jogo = request.form["nome_jogo"]
    unidades = request.form["unidades"]
    id_pedido = consultar_pedido(id_pedido)
    if id_pedido == None:
        return render_template("menu.html", mensagem = f"Pedido não existente!!"), 404
    editar_pedido(id_pedido, nome_cliente, nome_jogo, unidades)
    return render_template("menu.html", mensagem = f"O Pedido {id_pedido} do Cliente {nome_cliente} foi alterado com Sucesso.")

sql_create = """
CREATE TABLE IF NOT EXISTS jogo (
    id_jogo INTEGER PRIMARY KEY AUTOINCREMENT,
    nome_jogo VARCHAR(100) NOT NULL,
    descricao VARCHAR(200) NOT NULL,
    valor VARCHAR(10) NOT NULL,
    plataforma VARCHAR(20) NOT NULL
);

CREATE TABLE IF NOT EXISTS cliente (
    id_cliente INTEGER PRIMARY KEY AUTOINCREMENT,
    nome_cliente VARCHAR(50) NOT NULL,
    login VARCHAR(20) NOT NULL,
    senha VARCHAR(20) NOT NULL,
    cpf VARCHAR(11) NOT NULL
);

CREATE TABLE IF NOT EXISTS pedido (
    id_pedido INTEGER PRIMARY KEY AUTOINCREMENT,
    nome_cliente VARCHAR(50) NOT NULL,
    nome_jogo VARCHAR(100) NOT NULL,
    unidades INTEGER(3) NOT NULL
)
"""

def conectar():
    return sqlite3.connect('rrg_games.db')

def criar_bd():
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.executescript(sql_create)
        con.commit()

def listar_jogos():
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("SELECT id_jogo, nome_jogo, descricao, valor, plataforma FROM jogo")
        return rows_to_dict(cur.description, cur.fetchall())

def listar_jogos_ordem():
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("SELECT id_jogo, nome_jogo, descricao, valor, plataforma FROM jogo ORDER BY valor")
        return rows_to_dict(cur.description, cur.fetchall())

def consultar_jogo(id_jogo):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("SELECT id_jogo, nome_jogo, descricao, valor, plataforma FROM jogo WHER id_jogo = ?", (id_jogo, ))
        return row_to_dict(cur.description, cur.fetchone())

def criar_jogo(nome_jogo, descricao, valor, plataforma):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("INSERT INTO jogo (nome_jogo, descricao, valor, plataforma) VALUES (?, ?, ?, ?)", (nome_jogo, descricao, valor, plataforma))
        id_jogo = cur.lastrowid
        con.commit()
        return id_jogo

def editar_jogo(id_jogo, nome_jogo, descricao, valor, plataforma):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("UPDATE jogo SET nome_jogo = ?, descricao = ?, valor = ?, plataforma = ? WHERE id_jogo = ?", (nome_jogo, descricao, valor, plataforma, id_jogo))
        con.commit()

def deletar_jogo(id_jogo):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("DELETE FROM jogo WHERE id_jogo = ?", (id_jogo, ))
        con.commit()

#cliente

def listar_clientes():
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("SELECT id_cliente, nome_cliente, login, senha, cpf FROM cliente")
        return rows_to_dict(cur.description, cur.fetchall())

def consultar_cliente(id_cliente):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("SELECT id_cliente, nome_cliente, login, senha, cpf FROM cliente WHERE id_cliente = ?", (id_cliente, ))
        return row_to_dict(cur.description, cur.fetchone())

def criar_cliente(nome_cliente, login, senha, cpf):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("INSERT INTO cliente (nome_cliente, login, senha, cpf) VALUES (?, ?, ?, ?)", (nome_cliente, login, senha, cpf))
        id_cliente = cur.lastrowid
        con.commit()
        return id_cliente

def editar_cliente(id_cliente, nome_cliente, login, senha, cpf):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("UPDATE cliente SET nome_cliente = ?, login = ?, senha = ?, cpf = ? WHERE id_cliente = ?", (nome_cliente, login, senha, cpf, id_cliente))
        con.commit()

def deletar_cliente(id_cliente):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("DELETE FROM cliente WHERE id_cliente = ?", (id_cliente, ))
        con.commit()

#pedido

def criar_pedido(nome_cliente, nome_jogo, unidades):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("INSERT INTO pedido (nome_cliente, nome_jogo, unidades) VALUES (?, ?, ?)", (nome_cliente, nome_jogo, unidades))
        id_pedido = cur.lastrowid
        con.commit()
        return id_pedido

def listar_pedidos():
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("SELECT id_pedido, nome_cliente, nome_jogo, unidades FROM pedido ORDER BY id_pedido")
        return rows_to_dict(cur.description, cur.fetchall())

def consultar_pedido(id_pedido):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("SELECT id_pedido, nome_cliente, nome_jogo, unidades FROM pedido WHERE id_pedido = ?", (id_pedido, ))
        return row_to_dict(cur.description, cur.fetchone())

def editar_pedido(id_pedido, nome_cliente, nome_jogo, unidades):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("UPDATE pedido SET nome_cliente = ?, nome_jogo = ?, unidades = ? WHERE id_pedido = ?", (nome_cliente, nome_jogo, unidades, id_pedido))
        con.commit()

if __name__ == "__main__":
    criar_bd()
    app.run()