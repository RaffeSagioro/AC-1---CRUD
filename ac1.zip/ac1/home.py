from flask import Flask, request, render_template
from contextlib import closing
import sqlite3

app = Flask(__name__)

@app.route("/")
def menu():
    return render_template("menu.html", mensagem = "")

@app.route("/jogo")
def listar_jogos_api():
    return render_template("lista_jogos.html", jogos = listar_jogos())

@app.route("/jogo/novo", methods = ["GET"])
def form_criar_jogo_api():
    return render_template("jogos.html", id_jogo = "novo", jogo = "", valor = "")

@app.route("/jogo/novo", methods = ["POST"])
def criar_jogo_api():
    jogo = request.form["jogo"]
    valor = request.form["valor"]
    id_jogo = criar_jogo(jogo, valor)
    return render_template("menu.html", mensagem = f"Jogo Cadastrado")

@app.route("/cliente")
def listar_cliente_api():
    return render_template("lista_clientes.html", clientes = listar_clientes())

@app.route("/cliente/novo", methods = ["GET"])
def form_criar_cliente_api():
    return render_template("cliente.html", id_cliente = "novo", nome = "", sexo = "", cpf = "")

@app.route("/cliente/novo", methods = ["POST"])
def criar_cliente_api():
    nome = request.form["nome"]
    sexo = request.form["sexo"]
    cpf = request.form["cpf"]
    id_cliente = criar_cliente(nome, sexo, cpf)
    return render_template("menu.html", mensagem = f"{'O Cliente' if sexo == 'M' else 'A Cliente'} {nome} foi cadastrad{'o' if sexo == 'M' else 'a'} com o id {id_cliente}.")

@app.route("/cliente/<int:id_cliente>", methods = ["GET"])
def form_alterar_cliente_api(id_cliente):
    cliente = consultar_cliente(id_cliente)
    if cliente == None:
        return render_template("menu.html", mensagem = f"Esse cliente não existe."), 404
    return render_template("cliente.html", id_cliente = id_cliente, nome = cliente['nome'], sexo = cliente['sexo'], cpf = cliente['cpf'])

@app.route("/cliente/<int:id_cliente>", methods = ["POST"])
def alterar_cliente_api(id_cliente):
    nome = request.form["nome"]
    sexo = request.form["sexo"]
    cpf - request.form["cpf"]
    cliente = consultar_cliente(id_cliente)
    if cliente == None:
        return render_template("menu.html", mensagem = f"Ess{'e Cliente' if sexo == 'M' else 'a Cliente'} nem mesmo existia mais."), 404
    editar_cliente(id_cliente, nome, sexo, cpf)
    return render_template("menu.html", mensagem = f"{'O cliente' if sexo == 'M' else 'A Cliente'} {nome} com o id {id_cliente} foi editad{'o' if sexo == 'M' else 'a'}.")

@app.route("/cliente/<int:id_cliente>", methods = ["DELETE"])
def deletar_cliente_api(id_cliente):
    cliente = consultar_cliente(id_cliente)
    if cliente == None:
        return render_template("menu.html", mensagem = "Esse Cliente nem mesmo existia mais."), 404
    deletar_cliente(id_cliente)
    return render_template("menu.html", mensagem = f"{'O cliente' if cliente['sexo'] == 'M' else 'A cliente'} {cliente['nome']} com o id {id_cliente} foi excluíd{'o' if cliente['sexo'] == 'M' else 'a'}.")




def row_to_dict(description, row):
    if row == None:
        return None
    d = {}
    for i in range(0, len(row)):
        d[description[i][0]] = row[i]
    return d


def rows_to_dict(description, rows):
    result = []
    for row in rows:
        result.append(row_to_dict(description, row))
    return result



sql_create = """
CREATE TABLE IF NOT EXISTS jogo (
    id_jogo INTEGER PRIMARY KEY AUTOINCREMENT,
    jogo VARCHAR(50) NOT NULL,
    valor VARCHAR(10) NOT NULL
);

CREATE TABLE IF NOT EXISTS cliente (
    id_cliente INTEGER PRIMARY KEY AUTOINCREMENT,
    nome VARCHAR(50) NOT NULL,
    sexo VARCHAR(1) NOT NULL,
    cpf VARCHAR(14) NOT NULL
);
"""

def conectar():
    return sqlite3.connect('serie.db')

def criar_bd():
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.executescript(sql_create)
        con.commit()

def listar_jogos():
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("SELECT id_jogo, jogo, valor FROM jogo")
        return rows_to_dict(cur.description, cur.fetchall())

def listar_jogos_ordem():
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("SELECT id_jogo, jogo, valor FROM jogo ORDER BY jogo, valor")
        return rows_to_dict(cur.description, cur.fetchall())

def verificar_jogo(jogo, valor):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("SELECT id_jogo FROM jogo WHERE jogo = ? AND valor = ?", (jogo, valor))
        t = cur.fetchone()
        return None if t == None else t[0]

def consultar_cliente(id_cliente):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("SELECT id_cliente, nome, sexo, cpf")
        return row_to_dict(cur.description, cur.fetchone())

def listar_clientes():
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("SELECT id_cliente, nome, sexo, cpf")
        return rows_to_dict(cur.description, cur.fetchall())

def criar_jogo(jogo, valor):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("INSERT INTO jogo (jogo, valor) VALUES (?, ?)", (jogo, valor))
        id_jogo = cur.lastrowid
        con.commit()
        return id_jogo

def criar_cliente(nome, sexo, cpf):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("INSERT INTO cliente (nome, sexo, cpf) VALUES (?, ?, ?)", (nome, sexo, cpf))
        id_cliente = cur.lastrowid
        con.commit()
        return id_cliente

def editar_cliente(id_cliente, nome, sexo, cpf):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("UPDATE cliente SET nome = ?, sexo = ?, cpf = ? WHERE id_cliente = ?", (nome, sexo, cpf, id_cliente))
        con.commit()

def deletar_cliente(id_cliente):
    with closing(conectar()) as con, closing(con.cursor()) as cur:
        cur.execute("DELETE FROM cliente WHERE id_cliente = ?", (id_cliente, ))
        con.commit()


if __name__ == "__main__":
    criar_bd()
    app.run()